from flask import Flask, render_template, request
from Search import Search
import json


app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        return render_template("index.html")
    elif request.method == 'POST':
        searchTerm = request.form['Search']
        pages = int(request.form['Pages'])
        result = Search(searchTerm, pages)

        for x in range(1, pages + 1):
            for game in result[x]:
                try:
                    game['reviewSummary'] = game['reviewSummary'].replace(
                        "<br>", " Reviews, ")
                except:
                    pass
        return render_template("results.html", data=result, pages=pages)


if __name__ == '__main__':
    app.run(debug=True)
