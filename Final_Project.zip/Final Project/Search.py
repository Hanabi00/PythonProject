import requests
import json


def Search(term, pages):
    result = {}
    for x in range(1, pages + 1):
        url = f"https://steam2.p.rapidapi.com/search/{term}/page/{x}"

        headers = {
            "X-RapidAPI-Key": "61f499a172msh92b2f75f99db9b8p103f59jsn0eabeb279269",
            "X-RapidAPI-Host": "steam2.p.rapidapi.com"
        }

        response = requests.get(url, headers=headers)

        result[x] = response.json()
    return result


'''if x == 1:
            with open('data.json', 'w', encoding='utf-8') as f:
                json.dump(response.json(), f, ensure_ascii=False, indent=4)
        else:
            with open('data.json', 'a', encoding='utf-8') as f:
                json.dump(response.json(), f, ensure_ascii=False, indent=4)'''
